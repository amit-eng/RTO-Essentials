﻿a88888b. dP     dP  oo       dP           a8888a  d88  
d8'   `88 88     88           88          d8' ..8b  88  
88 d8P 88 88aaaaa88a dP .d888b88 .d8888b. 88 .P 88  88  
88 Yo8b88 88     88  88 88'  `88 88ooood8 88 d' 88  88  
Y8.       88     88  88 88.  .88 88.  ... Y8'' .8P  88  
 Y88888P' dP     dP  dP `88888P8 `88888P'  Y8888P  d88P 
ooooooooooooooooooooooooooooooooooooooooooooooooooooooo
      t.me/Hide01    hide01.ir
ooooooooooooooooooooooooooooooooooooooooooooooooooooooo


███████╗██████╗░███████╗███████╗    ███████╗░█████╗░██████╗░    ░█████╗░██╗░░░░░██╗░░░░░
██╔════╝██╔══██╗██╔════╝██╔════╝    ██╔════╝██╔══██╗██╔══██╗    ██╔══██╗██║░░░░░██║░░░░░
█████╗░░██████╔╝█████╗░░█████╗░░    █████╗░░██║░░██║██████╔╝    ███████║██║░░░░░██║░░░░░
██╔══╝░░██╔══██╗██╔══╝░░██╔══╝░░    ██╔══╝░░██║░░██║██╔══██╗    ██╔══██║██║░░░░░██║░░░░░
██║░░░░░██║░░██║███████╗███████╗    ██║░░░░░╚█████╔╝██║░░██║    ██║░░██║███████╗███████╗
╚═╝░░░░░╚═╝░░╚═╝╚══════╝╚══════╝    ╚═╝░░░░░░╚════╝░╚═╝░░╚═╝    ╚═╝░░╚═╝╚══════╝╚══════╝



 a88888b. .d88888b                              888888ba                      dP                       dP   
d8'   `88 88.    "'                             88    `8b                     88                       88   
88 d8P 88 `Y88888b. .d8888b. 88d888b. .d8888b. a88aaaa8P' .d8888b. 88d888b. d8888P .d8888b. .d8888b. d8888P 
88 Yo8b88       `8b 88'  `88 88'  `88 Y8ooooo.  88        88ooood8 88'  `88   88   88ooood8 Y8ooooo.   88   
Y8.       d8'   .8P 88.  .88 88    88       88  88        88.  ... 88    88   88   88.  ...       88   88   
 Y88888P'  Y88888P  `88888P8 dP    dP `88888P'  dP        `88888P' dP    dP   dP   `88888P' `88888P'   dP   
oooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo
            t.me/SansPentest
oooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo